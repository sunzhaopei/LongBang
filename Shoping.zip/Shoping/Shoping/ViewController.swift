//
//  ViewController.swift
//  Shoping
//
//  Created by ddp on 16/11/11.
//  Copyright © 2016年 ddp. All rights reserved.
//

import UIKit
import JavaScriptCore
@objc protocol JavaScriptSwiftDelegate:JSExport
{
    
    //定义协议 这边可以传参 也可以传字典啥的 可以定义多个方法
    //传多个参数用字典比较合适 单个参数直接传
    func payResult(dict: [String:AnyObject])
    
    
}//MARK:2. 然后定义一个模型 该模型实现SwiftJavaScriptDelegate协议
class JSModelSwift:NSObject,JavaScriptSwiftDelegate{
    weak var jsContext:JSContext?
    
    //定义模型方法
    func payResult(dict: [String:AnyObject])
    {
        let aa = UIAlertView.init(title: "你好", message: "兔兔兔兔", delegate: self, cancelButtonTitle: "取消")
        aa.show()
    
    }

}

class ViewController: UIViewController {
    /*JSContext：JSContext是JS的执行环境，通过evaluateScript()方法可以执行JS代码
     JSValue：JSValue封装了JS与ObjC中的对应的类型，以及调用JS的API等
     JSExport：JSExport是一个协议，遵守此协议，就可以定义我们自己的协议，在协议中声明的API都会在JS中暴露出来，这样JS才能调用原生的API*/
    weak var jsContext:JSContext?
    var result1:JSValue?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let webView = UIWebView.init(frame: CGRect.init(x: 0, y: 30, width: self.view.frame.size.width, height: self.view.frame.size.height-30))
       
        let path = NSBundle.mainBundle().pathForResource("test", ofType: "html")
      
        let htmlstring = try? NSString.init(contentsOfFile: path!, encoding: NSUTF8StringEncoding)
        let url = NSURL.fileURLWithPath(NSBundle.mainBundle().bundlePath, isDirectory: false)
        webView.loadHTMLString(htmlstring as! String,  baseURL: url )
//        let request = NSURLRequest.init(URL: NSURL.init(fileURLWithPath: path!))
//        webView.loadRequest(request)
        webView.delegate = self
        self.view.addSubview(webView)
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension ViewController:UIWebViewDelegate{
   
    func webView(webView: UIWebView, shouldStartLoadWithRequest request: NSURLRequest, navigationType: UIWebViewNavigationType) -> Bool{
        return true
    }
    func webViewDidStartLoad(webView: UIWebView){
    }
   
    func webViewDidFinishLoad(webView: UIWebView){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { 
            //创建js中的上下文环境
            let context = webView.valueForKeyPath("documentView.webView.mainFrame.javaScriptContext")as?JSContext
            //创建模型
            let model = JSModelSwift()
            model.jsContext = context
            self.jsContext = context
            
            self.jsContext?.setObject(model, forKeyedSubscript:"JSModel")
        }
       
        //捕捉异常可以不写
        self.jsContext?.exceptionHandler = {
            (context, exception) in
            print("exception @", exception)
        }
    }
}
